(function ($) {
  $(document).ready(function(){
    $('#uc-navigation div.primary div.menu-name-main-menu > ul.menu').dropmenu({moremenu:true});
  })
})(jQuery);
